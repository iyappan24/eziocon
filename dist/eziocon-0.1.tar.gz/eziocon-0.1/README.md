# eziocon
This repository consists of all the files which is a wrapper of python objects for generic functions for interacting with the Databases such as oracle, sql, mongodb
